# Full-head, half-head, and cyclic: a persistent gap

## Result

A multi-token copy task produces the requested empirical pattern: the full-head paired model performs very well, the half-head paired model is much worse even after 160,000 steps, and cyclic reaches performance close to full-head with the same query/key parameter count as half-head. This is a result on **this task and setup**, not a proof that half-head cannot represent a solution.

## Task and setup

Each input contains eight independently sampled integers (values 0–15), followed by a fixed end marker. At the final position the model must predict **all eight input values in order**, using eight categorical output slots. The metrics are (1) fraction of individual tokens correctly reconstructed and (2) fraction of examples for which all eight are correct. Random per-token chance is 1/16 = 6.25%.

The models use the supplied `cyclic_core.py`: one causal transformer layer, model width 64, four nominal heads with head dimension 16, FF width 32. Full pair has four attention maps; half-head pair has two maps with two value channels per map; cyclic has four maps. The shared task head emits 8 × 16 logits. Training uses independent online random examples, batch 128, Adam, learning rate 0.001, gradient norm clipping 1.0, 80,000 steps per run. All three models have identical task, layer count, width, data generation and training configuration; the attention variants do not have identical parameter initializations, even when given the same seed.

The selected task was initially screened using seeds 0–4 and a fixed monitoring set of 2,048 examples. The table below is a separate confirmation with **new training seeds 5–9** and a fresh final test set of 8,192 examples that was not used for the screening or intermediate monitoring. Means ± sample standard deviations are over five training seeds; all models are tested on the same final test set. This SD is not a measure of variation across test sets.

## Independent confirmation — 80,000 steps

| Model | Attention maps | QK parameters | Total parameters | Token accuracy | All 8 correct | Cross-entropy per token |
|---|---:|---:|---:|---:|---:|---:|
| Full-head pair | 4 | 8,192 | 31,808 | 99.15% ± 0.06 pp | 93.93% ± 0.50 pp | 0.0254 ± 0.0017 |
| Half-head pair | 2 | 4,096 | 27,712 | 82.63% ± 1.98 pp | 22.81% ± 4.90 pp | 0.4869 ± 0.0543 |
| Cyclic | 4 | 4,096 | 27,712 | 99.05% ± 0.07 pp | 93.18% ± 0.53 pp | 0.0285 ± 0.0026 |

Cyclic and half-head have identical QK and total parameter counts in this setup. Cyclic is **16.42 percentage points higher** than half-head in per-token accuracy and is **0.11 percentage points below** full-head. The latter is numerically close; this experiment does not establish exact equivalence or that cyclic beats full-head. Differences in attention map count and routing are also part of the architecture comparison, so the experiment does not isolate a single causal mechanism.

Test per-token accuracies by training seed (5–9), in percent:

- Full pair: 99.15, 99.21, 99.16, 99.20, 99.05.
- Half pair: 80.80, 84.55, 80.70, 84.81, 82.27.
- Cyclic: 98.95, 99.12, 99.11, 99.04, 99.00.

## Longer half-head training

Separately, seeds 0–4 were trained for 160,000 steps at learning rate 0.001. The following are results on the original shared 2,048-example monitoring set, not the independent final test in the table above:

| Steps | Half-head token accuracy, mean ± sample SD | All 8 correct, mean |
|---:|---:|---:|
| 40,000 | 82.24% | — |
| 80,000 | 83.83% ± 1.16 pp | 25.52% |
| 160,000 | 84.92% ± 1.08 pp | 28.39% |

The increase between 80k and 160k was about 1.09 percentage points on average: some improvement, but it remained far below full-head's 99.10% mean at 80k on the same monitoring set and same seeds. The five 160k per-token results were 85.21%, 84.53%, 86.05%, 85.56%, and 83.26%. Alternative learning rates 0.0003 and 0.002, each with two seeds at 80k, produced mean per-token accuracies of 83.29% and 84.03% on the monitoring set. These are limited controls, not an exhaustive optimizer search.

The first three 160k runs were completed before final-test/checkpoint saving was added to the script; their recorded curves are available, but their weights were not saved. Seeds 3–4 have checkpoints and independent final-test results.

## Additional difficulty: twelve-token copy

On the original 2,048-example monitoring set at 80k steps, five seeds each:

| Model | Token accuracy | All 12 correct |
|---|---:|---:|
| Full-head pair | 86.28% ± 0.93 pp | 21.25% ± 2.56 pp |
| Half-head pair | 60.44% ± 0.90 pp | 0.13% ± 0.13 pp |
| Cyclic | 86.13% ± 0.76 pp | 20.56% ± 2.34 pp |

This is supporting exploratory evidence, not a separate independent-test confirmation. Note that full pair itself does not solve the twelve-token task reliably as a complete sequence; the eight-token task is the cleaner primary result.

## Interpretation and limitations

- The results support the user's proposed performance pattern: cyclic can come close to full-head while clearly exceeding a same-QK-budget half-head pair on this task. They do not show cyclic beating full-head.
- The long-run evidence **does not prove a representational impossibility** for half-head. Its accuracy is still rising slowly; a different optimizer, learning-rate schedule, initialization, more training or a constructive solution could change the result. A formal capacity claim requires a proof or a controlled expressivity analysis.
- This artificial fixed-position copy task is not MQAR or language modelling, and uses one layer and a task-specific multi-slot output head. Its result should not be generalized without testing other tasks/configurations.
- This experiment measures predictive performance, not the proposed odd/even gradient conflict or collaboration. It cannot establish the phase-transition mechanism. A separate instrumentation experiment would be required.
- Raw traces and configs are in `results/`; `multi_copy.py` and the supplied `cyclic_core.py` reproduce the experiment. Checkpoints for the independent-confirmation runs and the two later 160k runs are in `checkpoints/`. All jobs ran on the user's A4000 GPUs and finished.
