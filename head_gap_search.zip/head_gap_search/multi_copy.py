"""Multi-token copy: predict each of K independent random source tokens at the
last position. Same user's cyclic_core models. Distinct output slots, categorical
CE, sample-wise exact and token-wise accuracy, fresh held-out batches.
Independent heads can route separate locations; this is an empirical probe, not
an expressivity proof. All arms use the same D,H,dh,L, FF, data, optimiser.
"""
import argparse,json,os,time
import torch
import torch.nn.functional as F
from cyclic_core import build_model, Trainer, seed_everything
p=argparse.ArgumentParser()
p.add_argument('--attn',choices=['pair','fewer_heads','cyclic'],required=True)
p.add_argument('--k',type=int,required=True)
p.add_argument('--steps',type=int,default=16000)
p.add_argument('--seeds',type=int,default=1)
p.add_argument('--start-seed',type=int,default=0)
p.add_argument('--d',type=int,default=64)
p.add_argument('--heads',type=int,default=4)
p.add_argument('--layers',type=int,default=1)
p.add_argument('--vocab',type=int,default=16)
p.add_argument('--lr',type=float,default=.001)
p.add_argument('--eval-every',type=int,default=2000)
p.add_argument('--out',required=True)
a=p.parse_args(); device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def batch(n,g):
    y=torch.randint(a.vocab,(n,a.k),generator=g)
    x=torch.cat((y,torch.full((n,1),a.vocab,dtype=torch.long)),1)
    return x,y

def lossfn(logits,y):
    return F.cross_entropy(logits[:,-1,:].reshape(-1,a.vocab),y.reshape(-1))

def evaluate(model,sets):
    model.eval(); correct=exact=count=examples=0; ce=0.
    with torch.no_grad():
        for x,y in sets:
            x=x.to(device); y=y.to(device); z,_=model(x); z=z[:,-1,:].reshape(-1,a.k,a.vocab)
            pred=z.argmax(-1); correct+=(pred==y).sum().item(); exact+=(pred==y).all(-1).sum().item()
            count+=y.numel(); examples+=len(y); ce+=F.cross_entropy(z.reshape(-1,a.vocab),y.reshape(-1),reduction='sum').item()
    return {'token_acc':correct/count,'exact_acc':exact/examples,'ce':ce/count,'n':examples}

def save(rows):
    os.makedirs(os.path.dirname(a.out) or '.',exist_ok=True)
    temp=a.out+'.tmp'; open(temp,'w').write(json.dumps({'config':vars(a),'runs':rows},indent=2)); os.replace(temp,a.out)

rows=[]
for seed in range(a.start_seed,a.start_seed+a.seeds):
    seed_everything(seed)
    model=build_model(vocab=a.vocab+1,attention=a.attn,d_model=a.d,n_heads=a.heads,
          head_dim=a.d//a.heads,ff=a.d//2,seq_len=a.k+1,n_layers=a.layers,num_classes=a.k*a.vocab)
    trainer=Trainer(model,lr=a.lr,device=device)
    eg=torch.Generator().manual_seed(9091); sets=[batch(256,eg) for _ in range(8)]
    g=torch.Generator().manual_seed(100031+seed); t=time.time()
    row={'seed':seed,'qk':model.qk_parameters(),'params':sum(p.numel() for p in model.parameters()),'curve':[]}; rows.append(row)
    for i in range(1,a.steps+1):
        x,y=batch(128,g); trainer.step(x,y,loss_fn=lossfn)
        if i%a.eval_every==0 or i==a.steps:
            r=evaluate(model,sets); r['step']=i; row['curve'].append(r); save(rows)
            print(f'{a.attn} k={a.k} seed={seed} step={i} token={r["token_acc"]:.4f} exact={r["exact_acc"]:.4f} ce={r["ce"]:.4f} sec={time.time()-t:.0f}',flush=True)
    # Independent final test is not used for intermediate monitoring or task selection.
    testg=torch.Generator().manual_seed(803129)
    testsets=[batch(256,testg) for _ in range(32)]
    row['final_test']=evaluate(model,testsets)
    save(rows)
    torch.save({'model':model.state_dict(),'optimizer':trainer.optimizer.state_dict(),
                'train_rng':g.get_state(),'step':a.steps,'config':vars(a)}, a.out+'.checkpoint.pt')
    print('FINAL_TEST',json.dumps(row['final_test']),flush=True)
print('DONE',flush=True)
