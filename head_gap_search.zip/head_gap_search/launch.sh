#!/bin/bash
set -eu
cd /media/storage/sidhu/head_gap_search
PY=/media/storage/sidhu/HydroGraphNet/hydro/bin/python
for k in 4 6 8 12; do
  case $k in 4|6) gpu=0;; *) gpu=1;; esac
  for arm in pair fewer_heads; do
    label="screen_${arm}_k${k}"
    setsid nohup env CUDA_VISIBLE_DEVICES=$gpu OMP_NUM_THREADS=1 "$PY" -u multi_copy.py --attn "$arm" --k "$k" --steps 16000 --seeds 1 --eval-every 2000 --out "${label}.json" > "${label}.log" 2>&1 < /dev/null &
    echo "launched $label gpu=$gpu pid=$!"
  done
done
