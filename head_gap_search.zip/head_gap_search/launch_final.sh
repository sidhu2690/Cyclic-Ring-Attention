#!/bin/bash
set -eu
cd /media/storage/sidhu/head_gap_search
PY=/media/storage/sidhu/HydroGraphNet/hydro/bin/python
launch () {
 gpu=$1; label=$2; shift 2
 setsid nohup env CUDA_VISIBLE_DEVICES=$gpu OMP_NUM_THREADS=1 "$PY" -u multi_copy.py "$@" --out "$label.json" > "$label.log" 2>&1 </dev/null &
 echo "$label gpu=$gpu pid=$!"
}
for seed in 5 6 7 8 9; do
 for arm in pair fewer_heads cyclic; do
  if [ $((seed%2)) -eq 0 ]; then gpu=0; else gpu=1; fi
  launch "$gpu" "test_${arm}_k8_s${seed}" --attn "$arm" --k 8 --steps 80000 --start-seed "$seed" --eval-every 10000
 done
done
for seed in 3 4; do
 launch 0 "extended_fewer_k8_s${seed}" --attn fewer_heads --k 8 --steps 160000 --start-seed "$seed" --eval-every 10000
done
