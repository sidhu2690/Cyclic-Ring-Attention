#!/bin/bash
set -eu
cd /media/storage/sidhu/head_gap_search
PY=/media/storage/sidhu/HydroGraphNet/hydro/bin/python
launch () {
  gpu=$1; label=$2; shift 2
  setsid nohup env CUDA_VISIBLE_DEVICES=$gpu OMP_NUM_THREADS=1 "$PY" -u multi_copy.py "$@" --out "$label.json" > "$label.log" 2>&1 </dev/null &
  echo "$label gpu=$gpu pid=$!"
}
for seed in 0 1 2 3 4; do
 launch 0 "cyclic_k8_s${seed}" --attn cyclic --k 8 --steps 80000 --start-seed "$seed" --eval-every 5000
 launch 1 "cyclic_k12_s${seed}" --attn cyclic --k 12 --steps 80000 --start-seed "$seed" --eval-every 5000
done
for seed in 0 1 2; do
 launch 0 "extended_fewer_k8_s${seed}" --attn fewer_heads --k 8 --steps 160000 --start-seed "$seed" --eval-every 10000
done
for seed in 0 1; do
 for lr in 0.0003 0.002; do
  launch 1 "lr${lr}_fewer_k8_s${seed}" --attn fewer_heads --k 8 --steps 80000 --start-seed "$seed" --lr "$lr" --eval-every 5000
 done
done
