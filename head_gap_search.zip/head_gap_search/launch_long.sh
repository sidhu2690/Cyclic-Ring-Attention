#!/bin/bash
set -eu
cd /media/storage/sidhu/head_gap_search
PY=/media/storage/sidhu/HydroGraphNet/hydro/bin/python
for k in 8 12; do
  if [ "$k" = 8 ]; then gpu=0; else gpu=1; fi
  for arm in pair fewer_heads; do
    for seed in 0 1 2 3 4; do
      label="long_${arm}_k${k}_s${seed}"
      setsid nohup env CUDA_VISIBLE_DEVICES=$gpu OMP_NUM_THREADS=1 "$PY" -u multi_copy.py --attn "$arm" --k "$k" --steps 80000 --start-seed "$seed" --seeds 1 --eval-every 5000 --out "${label}.json" > "${label}.log" 2>&1 < /dev/null &
      echo "launched $label gpu=$gpu pid=$!"
    done
  done
done
